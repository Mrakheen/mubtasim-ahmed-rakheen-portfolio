/* ==========================================================================
   particles.js — Atmospheric Deep-Space Layer
   Responsibilities:
     · Organic compound nebula clouds
     · Three-depth cosmic dust field (far / mid / near parallax)
     · Mouse atmosphere glow
     · Click nova bursts
     · Cinematic supernova events (flash → shockwave ring → fade)
     · Avatar void zone (natural clearing near the 3-D hero scene)
   Stars → stars.js  |  Meteors → shooting-stars.js
   ========================================================================== */

(function () {
  'use strict';

  const host = document.getElementById('particles-js');
  if (!host) return;

  const REDUCED = window.matchMedia('(prefers-reduced-motion:reduce)').matches;

  /* ── Canvas ────────────────────────────────────────────────────────────── */
  const canvas = document.createElement('canvas');
  canvas.setAttribute('aria-hidden', 'true');
  host.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  let W = 0, H = 0;

  /* ── Palettes ──────────────────────────────────────────────────────────── */
  /* Emission nebulae — ionised gas, themed violet/purple */
  const NEBULA_POOL = [
    { r:120, g:  0, b:210, base:0.038 },
    { r:150, g:  0, b:255, base:0.030 },
    { r: 90, g:  0, b:180, base:0.042 },
    { r:180, g:  0, b:255, base:0.024 },
    { r: 70, g:  0, b:160, base:0.034 },
    /* Reflection nebulae — scattered starlight, blue/teal */
    { r: 42, g:241, b:214, base:0.018 },
    { r: 60, g:120, b:220, base:0.022 },
    { r: 42, g: 80, b:200, base:0.025 },
  ];

  const NOVA_COLORS = [
    [255, 255, 255],
    [220, 178, 255],
    [155, 215, 255],
    [ 42, 241, 214],
  ];

  /* Supernova colour progression: white → blue-white → violet → remnant */
  const SN_PHASES = [
    { r:255, g:255, b:255 },
    { r:200, g:225, b:255 },
    { r:170, g:110, b:255 },
    { r:100, g:  0, b:180 },
  ];

  /* ── State ─────────────────────────────────────────────────────────────── */
  let elapsed = 0, lastTs = 0;
  let rafId = null, running = false;
  let scrollY = 0;

  const nebulae    = [];
  const dustFar    = [];
  const dustMid    = [];
  const dustNear   = [];
  const novas      = [];
  const supernovae = [];

  const mouse = { x: 0, y: 0, active: false };

  /* ── Utilities ─────────────────────────────────────────────────────────── */
  const rand  = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const lerp  = (a, b, t)   => a + (b - a) * t;

  /* Avatar void zone — natural atmospheric clearing near the 3-D scene.
     xFrac/yFrac is the approximate hero avatar position in the viewport.
     Returns 0 at void centre, 1 far outside.                           */
  const VOID = { xFrac: 0.73, yFrac: 0.44, radius: 230 };

  function voidFactor(x, y) {
    const dx   = x - W * VOID.xFrac;
    const dy   = y - H * VOID.yFrac;
    const dist = Math.sqrt(dx * dx + dy * dy);
    return clamp(dist / VOID.radius, 0, 1);
  }

  /* Spawn a position that avoids the void zone */
  function safePos(margin) {
    let x, y, tries = 0;
    do {
      x = rand(margin, W - margin);
      y = rand(margin, H - margin);
    } while (voidFactor(x, y) < 0.5 && ++tries < 25);
    return { x, y };
  }

  /* ── Nebula factory (compound organic blobs) ───────────────────────────── */
  function createNebula(isPrimary) {
    const col      = NEBULA_POOL[Math.floor(Math.random() * NEBULA_POOL.length)];
    const baseR    = isPrimary ? rand(160, 390) : rand(75, 180);
    const blobN    = isPrimary ? Math.floor(rand(3, 7)) : Math.floor(rand(2, 4));
    let   maxR     = 0;
    const blobs    = [];

    for (let i = 0; i < blobN; i++) {
      const r      = baseR * rand(0.35, 1.00);
      const angle  = rand(0, Math.PI * 2);
      const offset = rand(0, baseR * 0.52);
      maxR = Math.max(maxR, r + offset);
      blobs.push({
        dx:     Math.cos(angle) * offset,
        dy:     Math.sin(angle) * offset,
        r,
        oScale: rand(0.45, 1.00),
      });
    }

    const { x, y } = safePos(maxR + 20);
    const spd = isPrimary ? 0.65 : 1.0;

    return {
      x, y, blobs, maxR, col,
      vx:        rand(-0.10, 0.10) * spd,
      vy:        rand(-0.08, 0.08) * spd,
      rotation:  rand(0, Math.PI * 2),
      rotSpeed:  rand(-0.0004, 0.0004),
      phase:     rand(0, Math.PI * 2),
      pulseFreq: rand(0.03, 0.10),
    };
  }

  /* ── Dust factory ──────────────────────────────────────────────────────── */
  function createDust(cfg) {
    const depth = rand(0, 1);
    return {
      x: rand(0, W), y: rand(0, H),
      r:         lerp(cfg.rMax,  cfg.rMin,  depth),
      baseAlpha: lerp(cfg.aMax,  cfg.aMin,  depth),
      vx: rand(-cfg.spd, cfg.spd),
      vy: rand(-cfg.spd, cfg.spd),
      /* Brownian motion */
      bPhase: rand(0, Math.PI * 2),
      bFreq:  rand(0.06, 0.22),
      bAmp:   rand(0.002, 0.008),
      color:  cfg.color,
    };
  }

  function buildDustLayer(arr, cfg, count) {
    arr.length = 0;
    for (let i = 0; i < count; i++) arr.push(createDust(cfg));
  }

  /* ── Resize ────────────────────────────────────────────────────────────── */
  function resize() {
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width  = W;
    canvas.height = H;

    /* Nebulae */
    nebulae.length = 0;
    for (let i = 0; i < 5; i++) nebulae.push(createNebula(true));
    for (let i = 0; i < 6; i++) nebulae.push(createNebula(false));

    /* Dust — scale count to viewport area */
    const s = clamp((W * H) / (1440 * 800), 0.3, 2.0);
    buildDustLayer(dustFar,  { rMin:0.28, rMax:0.75, aMin:0.040, aMax:0.095, spd:0.014, color:[215,210,255] }, Math.round(200 * s));
    buildDustLayer(dustMid,  { rMin:0.55, rMax:1.30, aMin:0.048, aMax:0.130, spd:0.028, color:[200,200,255] }, Math.round(100 * s));
    buildDustLayer(dustNear, { rMin:0.90, rMax:1.90, aMin:0.055, aMax:0.150, spd:0.052, color:[185,185,255] }, Math.round( 45 * s));
  }

  /* ── Draw: nebulae ─────────────────────────────────────────────────────── */
  function drawNebulae() {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for (const n of nebulae) {
      const pulse  = 1 + Math.sin(elapsed * n.pulseFreq + n.phase) * 0.055;
      const { r, g, b, base } = n.col;
      ctx.save();
      ctx.translate(n.x, n.y);
      ctx.rotate(n.rotation);
      for (const blob of n.blobs) {
        /* Fade blob opacity near the avatar void zone */
        const cos = Math.cos(n.rotation), sin = Math.sin(n.rotation);
        const wx  = n.x + cos * blob.dx - sin * blob.dy;
        const wy  = n.y + sin * blob.dx + cos * blob.dy;
        const op  = base * blob.oScale * pulse * voidFactor(wx, wy);
        if (op < 0.002) continue;

        const grd = ctx.createRadialGradient(blob.dx, blob.dy, 0, blob.dx, blob.dy, blob.r);
        grd.addColorStop(0,    `rgba(${r},${g},${b},${op.toFixed(4)})`);
        grd.addColorStop(0.40, `rgba(${r},${g},${b},${(op*0.48).toFixed(4)})`);
        grd.addColorStop(0.75, `rgba(${r},${g},${b},${(op*0.12).toFixed(4)})`);
        grd.addColorStop(1,    `rgba(${r},${g},${b},0)`);
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.arc(blob.dx, blob.dy, blob.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
    ctx.restore();
  }

  /* ── Draw: dust layer ──────────────────────────────────────────────────── */
  function drawDustLayer(arr, scrollMult) {
    const mr  = 175, mr2 = mr * mr;
    const bst = 2.0;
    for (const d of arr) {
      let a = d.baseAlpha;
      if (mouse.active) {
        const dx = mouse.x - d.x, dy = mouse.y - d.y;
        const d2 = dx * dx + dy * dy;
        if (d2 < mr2) {
          const t = 1 - Math.sqrt(d2) / mr;
          a = Math.min(d.baseAlpha * bst, a + t * t * 0.10);
        }
      }
      const drawY = ((d.y - scrollY * scrollMult) % H + H) % H;
      const [r, g, b] = d.color;
      ctx.globalAlpha = clamp(a, 0, 1);
      ctx.fillStyle   = `rgb(${r},${g},${b})`;
      ctx.beginPath();
      ctx.arc(d.x, drawY, d.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function drawDust() {
    ctx.save();
    drawDustLayer(dustFar,  0.004);
    drawDustLayer(dustMid,  0.010);
    drawDustLayer(dustNear, 0.022);
    ctx.restore();
  }

  /* ── Draw: nova click bursts ───────────────────────────────────────────── */
  function drawNovas() {
    ctx.save();
    for (let i = novas.length - 1; i >= 0; i--) {
      const n = novas[i];
      n.x += n.vx; n.y += n.vy;
      n.vx *= 0.94; n.vy *= 0.94;
      n.life -= 0.022;
      if (n.life <= 0) { novas.splice(i, 1); continue; }
      const [r, g, b] = n.color;
      const a = n.life * n.life;
      ctx.globalAlpha = a;
      ctx.shadowBlur  = 10;
      ctx.shadowColor = `rgba(${r},${g},${b},0.8)`;
      ctx.fillStyle   = `rgb(${r},${g},${b})`;
      ctx.beginPath();
      ctx.arc(n.x, n.y, n.radius * n.life, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.shadowBlur  = 0;
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  /* ── Draw: supernovae (3-act cinematic) ────────────────────────────────── */
  function drawSupernovae() {
    if (!supernovae.length) return;
    ctx.save();
    ctx.globalCompositeOperation = 'screen';

    for (let i = supernovae.length - 1; i >= 0; i--) {
      const sn = supernovae[i];
      if (!sn.alive) { supernovae.splice(i, 1); continue; }
      const { x, y, maxR } = sn;

      /* ── Act 1: Flash ──────────────────────────────────────────────────── */
      if (sn.phase === 'flash') {
        sn.flashAge += 0.016;
        const t = sn.flashAge / 0.45;
        if (t >= 1) { sn.phase = 'expand'; continue; }

        const radius = t < 0.38
          ? (t / 0.38) * 52
          : (1 - (t - 0.38) / 0.62) * 52 + 6;
        const a = t < 0.4 ? t / 0.4 : 1.0;

        const grd = ctx.createRadialGradient(x, y, 0, x, y, radius * 3.5);
        grd.addColorStop(0,   `rgba(255,255,255,${a.toFixed(3)})`);
        grd.addColorStop(0.3, `rgba(220,240,255,${(a*0.72).toFixed(3)})`);
        grd.addColorStop(1,   'rgba(180,200,255,0)');
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.arc(x, y, radius * 3.5, 0, Math.PI * 2);
        ctx.fill();

      /* ── Act 2: Expansion ──────────────────────────────────────────────── */
      } else if (sn.phase === 'expand') {
        sn.expandAge += 0.016;
        const t  = sn.expandAge / 4.2;
        if (t >= 1) { sn.phase = 'fade'; continue; }

        /* Ease-out expansion */
        const ease = 1 - Math.pow(1 - t, 2.4);
        const rNow = maxR * ease;

        /* Colour progression across SN_PHASES */
        const pi   = Math.min(Math.floor(t * (SN_PHASES.length - 1)), SN_PHASES.length - 2);
        const pf   = t * (SN_PHASES.length - 1) - pi;
        const cA   = SN_PHASES[pi], cB = SN_PHASES[pi + 1];
        const cr   = Math.round(lerp(cA.r, cB.r, pf));
        const cg   = Math.round(lerp(cA.g, cB.g, pf));
        const cb   = Math.round(lerp(cA.b, cB.b, pf));
        const ba   = Math.max(0, 1 - t * 0.32);

        /* Bloom sphere */
        const bloom = ctx.createRadialGradient(x, y, 0, x, y, rNow);
        bloom.addColorStop(0,    `rgba(${cr},${cg},${cb},${(ba*0.28).toFixed(3)})`);
        bloom.addColorStop(0.55, `rgba(${cr},${cg},${cb},${(ba*0.09).toFixed(3)})`);
        bloom.addColorStop(1,    `rgba(${cr},${cg},${cb},0)`);
        ctx.fillStyle = bloom;
        ctx.beginPath();
        ctx.arc(x, y, rNow, 0, Math.PI * 2);
        ctx.fill();

        /* Shockwave ring */
        const rw  = Math.max(0.8, 5 * (1 - t * 0.7));
        const ra  = Math.max(0, 0.85 - t * 0.60);
        ctx.strokeStyle = `rgba(${cr},${cg},${cb},${ra.toFixed(3)})`;
        ctx.lineWidth   = rw;
        ctx.shadowBlur  = 14;
        ctx.shadowColor = `rgba(${cr},${cg},${cb},0.5)`;
        ctx.beginPath();
        ctx.arc(x, y, rNow, 0, Math.PI * 2);
        ctx.stroke();
        ctx.shadowBlur = 0;

        /* Inner secondary ring */
        if (rNow > 18) {
          const ia = Math.max(0, 0.38 - t * 0.48);
          if (ia > 0) {
            ctx.strokeStyle = `rgba(${cr},${cg},${cb},${ia.toFixed(3)})`;
            ctx.lineWidth   = rw * 0.5;
            ctx.beginPath();
            ctx.arc(x, y, rNow * 0.40, 0, Math.PI * 2);
            ctx.stroke();
          }
        }

      /* ── Act 3: Fade ───────────────────────────────────────────────────── */
      } else if (sn.phase === 'fade') {
        sn.fadeAge += 0.016;
        const t = sn.fadeAge / 3.0;
        if (t >= 1) { sn.alive = false; continue; }

        const fc  = SN_PHASES[3];
        const fa  = (1 - t) * (1 - t);

        const fade = ctx.createRadialGradient(x, y, 0, x, y, maxR);
        fade.addColorStop(0,    `rgba(${fc.r},${fc.g},${fc.b},${(fa*0.18).toFixed(4)})`);
        fade.addColorStop(0.45, `rgba(${fc.r},${fc.g},${fc.b},${(fa*0.07).toFixed(4)})`);
        fade.addColorStop(1,    `rgba(${fc.r},${fc.g},${fc.b},0)`);
        ctx.fillStyle = fade;
        ctx.beginPath();
        ctx.arc(x, y, maxR, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  /* ── Update: nebulae ───────────────────────────────────────────────────── */
  function updateNebulae() {
    for (const n of nebulae) {
      n.x        += n.vx;
      n.y        += n.vy;
      n.rotation += n.rotSpeed;
      const m = n.maxR + 20;
      if (n.x < -m)    n.x = W + m;
      if (n.x > W + m) n.x = -m;
      if (n.y < -m)    n.y = H + m;
      if (n.y > H + m) n.y = -m;
    }
  }

  /* ── Update: dust layer ────────────────────────────────────────────────── */
  function updateDustLayer(arr, cfg) {
    for (const d of arr) {
      /* Brownian drift */
      const b = Math.sin(elapsed * d.bFreq + d.bPhase) * d.bAmp;
      d.x += d.vx + b;
      d.y += d.vy + b * 0.5;
      /* Velocity damping + minimum speed */
      d.vx *= 0.993; d.vy *= 0.993;
      const min = cfg.spd * 0.25;
      if (Math.abs(d.vx) < min) d.vx += (d.vx < 0 ? -1 : 1) * 0.004;
      if (Math.abs(d.vy) < min) d.vy += (d.vy < 0 ? -1 : 1) * 0.004;
      /* Wrap */
      if (d.x < -4)    d.x = W + 4;
      if (d.x > W + 4) d.x = -4;
      if (d.y < -4)    d.y = H + 4;
      if (d.y > H + 4) d.y = -4;
    }
  }

  /* ── Master render ─────────────────────────────────────────────────────── */
  function render() {
    ctx.clearRect(0, 0, W, H);
    drawNebulae();
    drawDust();
    drawSupernovae();
    drawNovas();
  }

  /* ── Animation loop ────────────────────────────────────────────────────── */
  function frame(ts) {
    if (!running) return;
    const dt = Math.min((ts - (lastTs || ts)) / 1000, 0.05);
    elapsed += dt; lastTs = ts;
    updateNebulae();
    updateDustLayer(dustFar,  { spd: 0.014 });
    updateDustLayer(dustMid,  { spd: 0.028 });
    updateDustLayer(dustNear, { spd: 0.052 });
    render();
    rafId = requestAnimationFrame(frame);
  }

  function start() {
    if (running) return;
    if (REDUCED) { resize(); render(); return; }
    running = true;
    rafId   = requestAnimationFrame(frame);
  }
  function stop() {
    running = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
  }

  /* ── Supernova scheduler ───────────────────────────────────────────────── */
  (function schedule() {
    setTimeout(function tick() {
      if (running && !document.hidden && Math.random() < 0.30 && supernovae.length < 2) {
        const maxR = Math.min(W, H) * 0.32;
        const vx   = W * VOID.xFrac, vy = H * VOID.yFrac, avR = 340;
        let x, y, t = 0;
        do {
          x = rand(maxR, W - maxR);
          y = rand(maxR * 0.5, H - maxR * 0.5);
        } while (Math.sqrt((x-vx)**2 + (y-vy)**2) < avR && ++t < 28);
        supernovae.push({ x, y, maxR, alive: true, phase: 'flash', flashAge: 0, expandAge: 0, fadeAge: 0 });
      }
      setTimeout(tick, 20000);
    }, 20000);
  })();

  /* ── Events ────────────────────────────────────────────────────────────── */
  window.addEventListener('mousemove', e => {
    mouse.x = e.clientX; mouse.y = e.clientY; mouse.active = true;
  }, { passive: true });

  window.addEventListener('mouseleave', () => { mouse.active = false; }, { passive: true });

  window.addEventListener('scroll', () => { scrollY = window.scrollY; }, { passive: true });

  window.addEventListener('click', e => {
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2;
      const spd   = rand(1.2, 3.5);
      novas.push({
        x: e.clientX, y: e.clientY,
        vx: Math.cos(angle) * spd, vy: Math.sin(angle) * spd,
        life: 1, radius: rand(1.2, 2.8),
        color: NOVA_COLORS[Math.floor(Math.random() * NOVA_COLORS.length)],
      });
    }
  }, { passive: true });

  let rTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(rTimer); rTimer = setTimeout(resize, 150);
  }, { passive: true });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stop(); else start();
  });

  /* ── Boot ──────────────────────────────────────────────────────────────── */
  resize();
  start();

})();
