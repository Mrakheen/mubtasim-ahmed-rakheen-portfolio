/* ==========================================================================
   cursor.js — Interstellar Cursor
   Space targeting reticle · comet trail · click ripple
   ========================================================================== */

(() => {
  'use strict';

  /* ── Skip touch / no-hover devices ────────────────────────────────────── */
  if (window.matchMedia('(hover:none) and (pointer:coarse)').matches) return;

  const REDUCED = window.matchMedia('(prefers-reduced-motion:reduce)').matches;

  /* ── Config ────────────────────────────────────────────────────────────── */
  const CFG = {
    trailMax:    26,
    followSpeed: 0.13,
    hoverSpeed:  0.20,
    hoverScale:  1.45,
    rotSpeed:    0.18,   /* degrees per frame */
  };

  /* ── Trail canvas ──────────────────────────────────────────────────────── */
  const canvas = document.createElement('canvas');
  canvas.id = 'cursor-trail';
  document.body.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  let W = 0, H = 0;

  function resizeCanvas() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width  = W * dpr;
    canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas, { passive: true });

  /* ── Reticle ring ──────────────────────────────────────────────────────── */
  const outer = document.createElement('div');
  outer.id = 'cursor-outer';
  outer.innerHTML = `<svg viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="22" cy="22" r="18.5" stroke="currentColor" stroke-width="1.1" opacity="0.9"/>
    <line x1="22" y1="2"  x2="22" y2="11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
    <line x1="22" y1="33" x2="22" y2="42" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
    <line x1="2"  y1="22" x2="11" y2="22" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
    <line x1="33" y1="22" x2="42" y2="22" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
    <circle cx="22" cy="22" r="2.2" stroke="currentColor" stroke-width="1" opacity="0.45"/>
  </svg>`;
  document.body.appendChild(outer);

  /* ── Bright comet core ─────────────────────────────────────────────────── */
  /* Visual properties live in CSS (#cursor-core). JS only touches            */
  /* transform and opacity so CSS hover/click transitions work correctly.      */
  const core = document.createElement('div');
  core.id = 'cursor-core';
  document.body.appendChild(core);

  /* ── State ─────────────────────────────────────────────────────────────── */
  let mouseX  = -500, mouseY  = -500;
  let ringX   = -500, ringY   = -500;
  let visible  = false;
  let hovering = false;
  let scale    = 1;
  let rotation = 0;

  const trail   = [];   /* [{x,y}] comet path history   */
  const ripples = [];   /* [{x,y,r,a}] click ring bursts */

  /* ── Interactive selectors ─────────────────────────────────────────────── */
  const INTERACTIVE =
    'a,button,[role=button],input,textarea,select,' +
    '.btn,.project-card,.stack-chip,.feature-card,' +
    '.carousel-arrow,.profile-frame,.nav-links a,' +
    '.scroll-down,.scroll-up a';

  /* ── Events ────────────────────────────────────────────────────────────── */
  document.addEventListener('mousemove', e => {
    mouseX = e.clientX;
    mouseY = e.clientY;
    visible = true;

    const next = !!e.target.closest(INTERACTIVE);
    if (next !== hovering) {
      hovering = next;
      document.body.classList.toggle('cursor-hover', hovering);
    }

    if (!REDUCED) {
      trail.push({ x: mouseX, y: mouseY });
      if (trail.length > CFG.trailMax) trail.shift();
    }
  }, { passive: true });

  document.addEventListener('mouseenter', () => { visible = true; });

  document.addEventListener('mouseleave', () => {
    visible = false;
    document.body.classList.remove('cursor-hover');
  });

  document.addEventListener('mousedown', () => {
    document.body.classList.add('cursor-click');
    if (!REDUCED) ripples.push({ x: mouseX, y: mouseY, r: 0, a: 0.80 });
    setTimeout(() => document.body.classList.remove('cursor-click'), 200);
  });

  /* ── Helpers ───────────────────────────────────────────────────────────── */
  const lerp = (a, b, t) => a + (b - a) * t;

  /* ── Draw: comet trail ─────────────────────────────────────────────────── */
  function drawTrail() {
    if (trail.length < 2) return;

    for (let i = 1; i < trail.length; i++) {
      const p0 = trail[i - 1];
      const p1 = trail[i];
      const t  = i / trail.length;          /* 0 = oldest, 1 = newest */

      /* Colour: violet (tail) → aurora teal (head) */
      const r = Math.round(lerp(160,  42, t));
      const g = Math.round(lerp(  0, 241, t));
      const b = Math.round(lerp(220, 214, t));
      const a = Math.pow(t, 2.6) * 0.90;

      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y);
      ctx.lineTo(p1.x, p1.y);
      ctx.strokeStyle = `rgba(${r},${g},${b},${a.toFixed(3)})`;
      ctx.lineWidth   = 0.25 + t * 4.0;
      ctx.lineCap     = 'round';
      ctx.stroke();
    }

    /* Soft radial glow at trail head */
    const head = trail[trail.length - 1];
    const glow = ctx.createRadialGradient(head.x, head.y, 0, head.x, head.y, 22);
    glow.addColorStop(0,    'rgba(255,255,255,0.88)');
    glow.addColorStop(0.22, 'rgba(255,255,255,0.55)');
    glow.addColorStop(0.55, 'rgba(42,241,214,0.26)');
    glow.addColorStop(1,    'rgba(42,241,214,0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(head.x, head.y, 22, 0, Math.PI * 2);
    ctx.fill();
  }

  /* ── Draw: click ripples ───────────────────────────────────────────────── */
  function drawRipples() {
    for (let i = ripples.length - 1; i >= 0; i--) {
      const rp = ripples[i];
      rp.r += 3.2;
      rp.a *= 0.88;
      if (rp.a < 0.01) { ripples.splice(i, 1); continue; }

      /* Outer teal ring */
      ctx.beginPath();
      ctx.arc(rp.x, rp.y, rp.r, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(42,241,214,${rp.a.toFixed(3)})`;
      ctx.lineWidth   = 1.4;
      ctx.stroke();

      /* Inner brighter ring (half radius, fades faster) */
      if (rp.r > 8) {
        ctx.beginPath();
        ctx.arc(rp.x, rp.y, rp.r * 0.45, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(255,255,255,${(rp.a * 0.6).toFixed(3)})`;
        ctx.lineWidth   = 0.8;
        ctx.stroke();
      }
    }
  }

  /* ── Animation loop ────────────────────────────────────────────────────── */
  function animate() {
    requestAnimationFrame(animate);

    ctx.clearRect(0, 0, W, H);

    if (!visible) {
      outer.style.opacity = '0';
      core.style.opacity  = '0';
      return;
    }

    /* Lerp ring toward mouse */
    const spd = hovering ? CFG.hoverSpeed : CFG.followSpeed;
    ringX = lerp(ringX, mouseX, spd);
    ringY = lerp(ringY, mouseY, spd);

    /* Lerp scale */
    scale = lerp(scale, hovering ? CFG.hoverScale : 1.0, 0.16);

    /* Rotation */
    if (!REDUCED) rotation += CFG.rotSpeed;

    /* Ring colour: teal default / violet on hover */
    outer.style.color = hovering ? '#d060ff' : '#2af1d6';

    /* Position outer ring — element is 44×44 px, centre offset = 22 */
    outer.style.transform =
      `translate3d(${(ringX - 22).toFixed(2)}px,${(ringY - 22).toFixed(2)}px,0) rotate(${rotation.toFixed(2)}deg) scale(${scale.toFixed(4)})`;
    outer.style.opacity = '1';

    /* Position core — element is 6×6 px, centre offset = 3 */
    core.style.transform =
      `translate3d(${(mouseX - 3).toFixed(2)}px,${(mouseY - 3).toFixed(2)}px,0)`;
    core.style.opacity = '1';

    /* Canvas effects */
    if (!REDUCED) {
      drawTrail();
      drawRipples();
    }
  }

  animate();
})();
