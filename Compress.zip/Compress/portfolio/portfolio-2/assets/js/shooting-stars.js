/* =========================================================================
   shooting-stars.js
   Canvas-based shooting stars with real diagonal motion, glowing head,
   and a gradient trail that fades along the direction of travel.
   Replaces the old CSS-animation approach entirely.
   ========================================================================= */
(function () {
  'use strict';

  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  const host = document.getElementById('shootingStars');
  if (!host) return;

  /* ── Canvas setup ──────────────────────────────────────────────────── */
  const canvas = document.createElement('canvas');
  canvas.setAttribute('aria-hidden', 'true');
  canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;';
  host.appendChild(canvas);
  const ctx = canvas.getContext('2d');

  let W = 0, H = 0;

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize, { passive: true });

  /* ── Star class ────────────────────────────────────────────────────── */
  const PALETTE = [
    '255,255,255',   // pure white
    '210,180,255',   // soft violet
    '160,230,255',   // ice-blue
    '255,220,180',   // warm gold
  ];

  class ShootingStar {
    constructor() { this.init(); }

    init() {
      /* Spawn: 70% from top edge, 30% from right edge */
      if (Math.random() < 0.7) {
        this.x = W * (0.05 + Math.random() * 1.1);  // spread slightly beyond edges
        this.y = -10;
      } else {
        this.x = W + 10;
        this.y = H * (Math.random() * 0.55);
      }

      /* Angle: 205° – 245° (down-left diagonal, like real meteors) */
      const directions = [
        [205,245],
        [120,155],
        [285,320]
      ];
      const pick = directions[Math.floor(Math.random()*directions.length)];
      const angleDeg = pick[0] + Math.random()*(pick[1]-pick[0]);

      const angleRad = angleDeg * (Math.PI / 180);

      this.speed  = 5 + Math.random() * 7;          // px per frame
      this.vx     = Math.cos(angleRad) * this.speed;
      this.vy     = Math.sin(angleRad) * this.speed;

      this.trailLen = 180 + Math.random() * 260;     // px
      this.lineW    = 0.8 + Math.random() * 1.4;    // stroke width

      /* Lifetime: enough frames to cross roughly 40% of the screen */
      this.maxLife = Math.round((this.trailLen + Math.hypot(W, H) * 0.38) / this.speed);
      this.life    = 0;
      this.alpha   = 0;

      this.color = PALETTE[Math.floor(Math.random() * PALETTE.length)];
    }

    /** Returns false when the star should be recycled */
    update() {
      this.x += this.vx;
      this.y += this.vy;
      this.life++;

      const t = this.life / this.maxLife;
      /* Smooth ease-in for first 12%, hold, ease-out for last 22% */
      if      (t < 0.12) this.alpha = t / 0.12;
      else if (t > 0.78) this.alpha = 1 - (t - 0.78) / 0.22;
      else               this.alpha = 1;

      return this.life < this.maxLife
          && this.x > -300 && this.x < W + 300
          && this.y > -300 && this.y < H + 300;
    }

    draw(ctx) {
      /* Tail endpoint (opposite to travel direction) */
      const nx  = this.vx / this.speed;  // unit vector x
      const ny  = this.vy / this.speed;  // unit vector y
      const tx  = this.x - nx * this.trailLen;
      const ty  = this.y - ny * this.trailLen;

      /* Gradient along the exact direction of travel */
      const grad = ctx.createLinearGradient(tx, ty, this.x, this.y);
      grad.addColorStop(0,    `rgba(${this.color},0)`);
      grad.addColorStop(0.55, `rgba(${this.color},${(this.alpha * 0.18).toFixed(3)})`);
      grad.addColorStop(0.85, `rgba(${this.color},${(this.alpha * 0.55).toFixed(3)})`);
      grad.addColorStop(1,    `rgba(${this.color},${this.alpha.toFixed(3)})`);

      ctx.save();
      ctx.globalCompositeOperation = 'screen';

      /* Trail */
      ctx.beginPath();
      ctx.moveTo(tx, ty);
      ctx.lineTo(this.x, this.y);
      ctx.strokeStyle = grad;
      ctx.lineWidth   = this.lineW;
      ctx.lineCap     = 'round';
      ctx.stroke();

      /* Glowing head */
      const headR = this.lineW * 1.8;
      ctx.shadowBlur  = 24;
      ctx.shadowColor = `rgba(${this.color},${this.alpha.toFixed(3)})`;
      ctx.beginPath();
      ctx.arc(this.x, this.y, headR, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,255,255,${this.alpha.toFixed(3)})`;
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.restore();
    }
  }

  /* ── Pool & spawn timing ───────────────────────────────────────────── */
  const stars = [];
  const MAX   = 8;   // max on screen at once

  let nextSpawn  = performance.now() + 1800;
  const MIN_GAP  = 900;   // ms between spawns (min)
  const MAX_GAP  = 3500;   // ms between spawns (max)

  function scheduleNext() {
    nextSpawn = performance.now() + MIN_GAP + Math.random() * (MAX_GAP - MIN_GAP);
  }

  /* ── Render loop ───────────────────────────────────────────────────── */
  let rafId   = null;
  let running = false;

  function frame(now) {
    if (!running) return;

    /* Spawn */
    if (now >= nextSpawn && stars.length < MAX) {
      stars.push(new ShootingStar());
      scheduleNext();
    }

    /* Clear only if there's something to draw (avoids unnecessary clears) */
    if (stars.length > 0) {
      ctx.clearRect(0, 0, W, H);

      /* Update & draw each star; remove dead ones */
      for (let i = stars.length - 1; i >= 0; i--) {
        const alive = stars[i].update();
        if (alive) {
          stars[i].draw(ctx);
        } else {
          stars.splice(i, 1);
        }
      }
    }

    rafId = requestAnimationFrame(frame);
  }

  function start() {
    if (running) return;
    running = true;
    rafId   = requestAnimationFrame(frame);
  }
  function stop() {
    running = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
  }

  /* Pause when tab is hidden */
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stop();
    else start();
  });

  start();
})();
