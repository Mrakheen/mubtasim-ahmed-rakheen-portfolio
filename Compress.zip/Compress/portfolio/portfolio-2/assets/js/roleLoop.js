/* =========================================================================
   roleLoop.js — hero typing / deleting animation + cursor blink
   Vanilla JS, no dependencies. Respects prefers-reduced-motion.
   ========================================================================= */
(function () {
  'use strict';

  const roles = [
    'Full Stack Development',
    '.NET Framework',
    'Cloud Services',
    'Agentic AI',
    'UI/UX Design',
  ];

  const TYPING_MS  = 110;   // ms per character typed
  const DELETING_MS = 70;   // ms per character deleted
  const PAUSE_MS   = 2200;  // pause after full role is shown

  const roleEl   = document.getElementById('role');
  const cursorEl = document.getElementById('cursor');

  if (!roleEl) return;

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* --- cursor blink --------------------------------------------------- */
  if (cursorEl) {
    const style = document.createElement('style');
    style.textContent = `
      @keyframes cursor-blink {
        0%, 100% { opacity: 1; }
        50%       { opacity: 0; }
      }
      #cursor { animation: cursor-blink 1.05s step-start infinite; }
    `;
    document.head.appendChild(style);
  }

  /* --- reduced-motion fallback: just show all roles cycling slowly ---- */
  if (prefersReducedMotion) {
    let i = 0;
    roleEl.textContent = roles[i];
    setInterval(() => {
      i = (i + 1) % roles.length;
      roleEl.textContent = roles[i];
    }, 4000);
    return;
  }

  /* --- typing engine -------------------------------------------------- */
  let roleIndex  = 0;
  let charIndex  = 0;
  let isDeleting = false;
  let timerId    = null;

  function tick() {
    const current = roles[roleIndex];

    if (!isDeleting) {
      charIndex++;
      roleEl.textContent = current.slice(0, charIndex);

      if (charIndex === current.length) {
        isDeleting = true;
        timerId = setTimeout(tick, PAUSE_MS);
        return;
      }
    } else {
      charIndex--;
      roleEl.textContent = current.slice(0, charIndex);

      if (charIndex === 0) {
        isDeleting = false;
        roleIndex  = (roleIndex + 1) % roles.length;
      }
    }

    timerId = setTimeout(tick, isDeleting ? DELETING_MS : TYPING_MS);
  }

  function start() {
    if (!timerId) tick();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
