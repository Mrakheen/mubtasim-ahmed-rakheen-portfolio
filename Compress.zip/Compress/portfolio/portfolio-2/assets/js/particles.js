/* ==========================================================================
   particles.js — Atmospheric Deep-Space Layer
   Clean, self-contained rewrite. No globals, no broken references.

   Features:
     · Organic compound nebula clouds (multi-blob, rotating)
     · Parallax camera drift (gentle float through space)
     · Three-depth cosmic dust field (far / mid / near)
     · Mouse atmosphere glow
     · Click nova bursts (plasma wisps + hot core)
     · Cinematic supernova events (flash → plasma expansion → remnant fade)
     · Avatar void zone (clearing near the 3-D hero)

   Stars  → stars.js  |  Meteors → shooting-stars.js
   ========================================================================== */

(function () {
  'use strict';

  /* ── Guard ────────────────────────────────────────────────────────────── */
  const host = document.getElementById('particles-js');
  if (!host) return;

  const REDUCED = window.matchMedia('(prefers-reduced-motion:reduce)').matches;

  /* ── Canvas ───────────────────────────────────────────────────────────── */
  const canvas = document.createElement('canvas');
  canvas.setAttribute('aria-hidden', 'true');
  host.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  let W = 0, H = 0;

  /* ── Palettes ─────────────────────────────────────────────────────────── */
  const NEBULA_POOL = [
    { r:120, g:  0, b:210, base:0.038 },
    { r:150, g:  0, b:255, base:0.030 },
    { r: 90, g:  0, b:180, base:0.042 },
    { r:180, g:  0, b:255, base:0.024 },
    { r: 70, g:  0, b:160, base:0.034 },
    { r: 42, g:241, b:214, base:0.018 },
    { r: 60, g:120, b:220, base:0.022 },
    { r: 42, g: 80, b:200, base:0.025 },
  ];

  const NOVA_COLORS = [
    [255, 255, 255],
    [220, 178, 255],
    [155, 215, 255],
    [ 42, 241, 214],
  ];

  const SN_PHASES = [
    { r:255, g:255, b:255 },
    { r:200, g:225, b:255 },
    { r:170, g:110, b:255 },
    { r:100, g:  0, b:180 },
  ];

  /* ── Utilities ────────────────────────────────────────────────────────── */
  const rand  = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const lerp  = (a, b, t)   => a + (b - a) * t;

  /* ── Avatar void zone ─────────────────────────────────────────────────── */
  /* Nebulae and dust naturally clear around the 3-D hero avatar.
     xFrac/yFrac = approximate avatar centre in the viewport.             */
  const VOID = { xFrac: 0.73, yFrac: 0.44, radius: 230 };

  function voidFactor(x, y) {
    const dx = x - W * VOID.xFrac;
    const dy = y - H * VOID.yFrac;
    return clamp(Math.sqrt(dx * dx + dy * dy) / VOID.radius, 0, 1);
  }

  function safePos(margin) {
    let x, y, tries = 0;
    do {
      x = rand(margin, W - margin);
      y = rand(margin, H - margin);
    } while (voidFactor(x, y) < 0.5 && ++tries < 25);
    return { x, y };
  }

  /* ── Camera drift ─────────────────────────────────────────────────────── */
  /* A very slow gentle drift gives the parallax "floating in space" feel.
     We offset every projected position by (camX, camY) scaled per depth.  */
  let camX = 0, camY = 0;
  let driftAngle = Math.random() * Math.PI * 2;

  function updateCamera(dt) {
    driftAngle += dt * 0.06;                        /* direction changes slowly */
    camX += Math.cos(driftAngle) * 0.18 * dt * 60; /* ~0.18 px/frame at 60 fps */
    camY += Math.sin(driftAngle) * 0.12 * dt * 60;
  }

  /* ── State ────────────────────────────────────────────────────────────── */
  let elapsed = 0, lastTs = 0;
  let rafId = null, running = false;
  let scrollY = 0;

  const nebulae    = [];
  const dustFar    = [];
  const dustMid    = [];
  const dustNear   = [];
  const novas      = [];
  const supernovae = [];

  const mouse = { x: 0, y: 0, active: false };

  /* =========================================================================
     NEBULA SYSTEM
     Compound multi-blob clouds. Each cloud is a group of overlapping radial
     gradients rotated together, giving an organic irregular shape.
     ========================================================================= */

  function createNebula(isPrimary) {
    const col   = NEBULA_POOL[Math.floor(Math.random() * NEBULA_POOL.length)];
    const baseR = isPrimary ? rand(160, 380) : rand(75, 180);
    const n     = isPrimary ? Math.floor(rand(3, 7)) : Math.floor(rand(2, 4));
    let   maxR  = 0;
    const blobs = [];

    for (let i = 0; i < n; i++) {
      const r      = baseR * rand(0.35, 1.0);
      const angle  = rand(0, Math.PI * 2);
      const offset = rand(0, baseR * 0.52);
      maxR = Math.max(maxR, r + offset);
      blobs.push({
        dx:     Math.cos(angle) * offset,
        dy:     Math.sin(angle) * offset,
        r,
        oScale: rand(0.45, 1.0),
      });
    }

    const { x, y } = safePos(maxR + 20);

    return {
      x, y, blobs, maxR, col,
      /* depth factor: 0.4 (far-ish) → 1.0 (near). Affects parallax offset. */
      depth:     rand(0.4, 1.0),
      vx:        rand(-0.06, 0.06) * (isPrimary ? 0.6 : 1.0),
      vy:        rand(-0.05, 0.05) * (isPrimary ? 0.6 : 1.0),
      rotation:  rand(0, Math.PI * 2),
      rotSpeed:  rand(-0.0004, 0.0004),
      phase:     rand(0, Math.PI * 2),
      pulseFreq: rand(0.03, 0.10),
    };
  }

  function drawNebulae() {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';

    for (const n of nebulae) {
      /* Parallax: deeper nebulae move less with the camera */
      const px = n.x - camX * n.depth;
      const py = n.y - camY * n.depth;

      const pulse = 1 + Math.sin(elapsed * n.pulseFreq + n.phase) * 0.055;
      const { r, g, b, base } = n.col;

      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(n.rotation);

      for (const blob of n.blobs) {
        /* World position of blob centre (approx) for void-zone check */
        const wx  = px + Math.cos(n.rotation) * blob.dx - Math.sin(n.rotation) * blob.dy;
        const wy  = py + Math.sin(n.rotation) * blob.dx + Math.cos(n.rotation) * blob.dy;
        const vf  = voidFactor(wx, wy);
        const op  = base * blob.oScale * pulse * vf;
        if (op < 0.002) continue;

        const grd = ctx.createRadialGradient(blob.dx, blob.dy, 0, blob.dx, blob.dy, blob.r);
        grd.addColorStop(0,    `rgba(${r},${g},${b},${op.toFixed(4)})`);
        grd.addColorStop(0.40, `rgba(${r},${g},${b},${(op * 0.48).toFixed(4)})`);
        grd.addColorStop(0.75, `rgba(${r},${g},${b},${(op * 0.12).toFixed(4)})`);
        grd.addColorStop(1,    `rgba(${r},${g},${b},0)`);
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.arc(blob.dx, blob.dy, blob.r, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }

    ctx.restore();
  }

  function updateNebulae() {
    for (const n of nebulae) {
      n.x        += n.vx;
      n.y        += n.vy;
      n.rotation += n.rotSpeed;
      const m = n.maxR + 20;
      if (n.x < -m)    n.x = W + m;
      if (n.x > W + m) n.x = -m;
      if (n.y < -m)    n.y = H + m;
      if (n.y > H + m) n.y = -m;
    }
  }

  /* =========================================================================
     DUST SYSTEM
     Three depth layers. Each particle has brownian motion on top of base
     velocity. Mouse proximity causes a subtle brightness boost (lens glow).
     ========================================================================= */

  function createDust(cfg) {
    const depth = Math.random();
    return {
      x: rand(0, W), y: rand(0, H),
      depth,
      r:         lerp(cfg.rMax,  cfg.rMin,  depth),
      baseAlpha: lerp(cfg.aMax,  cfg.aMin,  depth),
      vx: rand(-cfg.spd, cfg.spd),
      vy: rand(-cfg.spd, cfg.spd),
      /* Brownian micro-motion */
      bPhase: rand(0, Math.PI * 2),
      bFreq:  rand(0.06, 0.22),
      bAmp:   rand(0.002, 0.008),
      color:  cfg.color,
    };
  }

  function buildDustLayer(arr, cfg, count) {
    arr.length = 0;
    for (let i = 0; i < count; i++) arr.push(createDust(cfg));
  }

  function drawDustLayer(arr, camMult, scrollMult) {
    const MR  = 175, MR2 = MR * MR;
    for (const d of arr) {
      /* Parallax: depth 0 = still, depth 1 = full camera movement */
      const drawX = d.x - camX * d.depth * camMult;
      const drawY = ((d.y - camY * d.depth * camMult - scrollY * scrollMult) % H + H) % H;

      /* Mouse glow */
      let a = d.baseAlpha;
      if (mouse.active) {
        const dx = mouse.x - drawX, dy = mouse.y - drawY;
        const d2 = dx * dx + dy * dy;
        if (d2 < MR2) {
          const t = 1 - Math.sqrt(d2) / MR;
          a = Math.min(d.baseAlpha * 2.2, a + t * t * 0.10);
        }
      }

      const [r, g, b] = d.color;
      ctx.globalAlpha = clamp(a, 0, 1);
      ctx.fillStyle   = `rgb(${r},${g},${b})`;
      ctx.beginPath();
      ctx.arc(drawX, drawY, d.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function drawDust() {
    ctx.save();
    drawDustLayer(dustFar,  0.3, 0.004);
    drawDustLayer(dustMid,  0.6, 0.010);
    drawDustLayer(dustNear, 1.0, 0.022);
    ctx.restore();
  }

  function updateDustLayer(arr) {
    for (const d of arr) {
      const b = Math.sin(elapsed * d.bFreq + d.bPhase) * d.bAmp;
      d.x += d.vx + b;
      d.y += d.vy + b * 0.5;
      d.vx *= 0.993; d.vy *= 0.993;
      if (d.x < -4)    d.x = W + 4;
      if (d.x > W + 4) d.x = -4;
      if (d.y < -4)    d.y = H + 4;
      if (d.y > H + 4) d.y = -4;
    }
  }

  /* =========================================================================
     NOVA BURST SYSTEM (click effect)
     12 plasma sparks radiate from click point: glowing plasma ball +
     6 orbital wisps + hot white core. Each spark fades over ~1 second.
     ========================================================================= */

  function drawNovas() {
    if (!novas.length) return;

    ctx.save();
    ctx.globalCompositeOperation = 'screen';

    const now = elapsed * 8;

    for (let i = novas.length - 1; i >= 0; i--) {
      const n = novas[i];

      // motion
      n.x += n.vx;
      n.y += n.vy;
      n.vx *= 0.93;
      n.vy *= 0.93;

      n.life -= 0.022;

      if (n.life <= 0) {
        novas.splice(i, 1);
        continue;
      }

      const [rc, gc, bc] = n.color;
      const alpha = n.life * n.life;

      const radius = n.radius * (1.4 - n.life) * 6;

      /* ─────────────────────────────
        MAIN NOVA GLOW (PURE CIRCLE BLOOM)
      ───────────────────────────── */

      const glow = ctx.createRadialGradient(
        n.x,
        n.y,
        0,
        n.x,
        n.y,
        radius
      );

      glow.addColorStop(0, `rgba(255,255,255,${alpha})`);
      glow.addColorStop(0.2, `rgba(${rc},${gc},${bc},${alpha * 0.7})`);
      glow.addColorStop(0.6, `rgba(${rc},${gc},${bc},${alpha * 0.25})`);
      glow.addColorStop(1, `rgba(${rc},${gc},${bc},0)`);

      ctx.fillStyle = glow;

      ctx.beginPath();
      ctx.arc(n.x, n.y, radius, 0, Math.PI * 2);
      ctx.fill();

      /* ─────────────────────────────
        SOFT HOT CORE (NO EDGE)
      ───────────────────────────── */

      const coreR = radius * 0.18;

      const core = ctx.createRadialGradient(
        n.x,
        n.y,
        0,
        n.x,
        n.y,
        coreR
      );

      core.addColorStop(0, `rgba(255,255,255,${alpha})`);
      core.addColorStop(1, 'rgba(255,255,255,0)');

      ctx.fillStyle = core;

      ctx.beginPath();
      ctx.arc(n.x, n.y, coreR, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }

  /* =========================================================================
     SUPERNOVA SYSTEM — 3-act cinematic event
  ================================================================== */

  function drawSupernovae() {
    if (!supernovae.length) return;

    ctx.save();
    ctx.globalCompositeOperation = 'screen';

    const now = elapsed;

    for (let i = supernovae.length - 1; i >= 0; i--) {
      const sn = supernovae[i];

      if (!sn.alive) {
        supernovae.splice(i, 1);
        continue;
      }

      const { x, y, maxR } = sn;

      /* ─────────────────────────────
        ACT 1: FLASH (pure bloom)
      ───────────────────────────── */
      if (sn.phase === 'flash') {
        sn.flashAge += 0.016;
        const t = Math.min(sn.flashAge / 0.5, 1);

        if (t >= 1) {
          sn.phase = 'expand';
          continue;
        }

        const radius = 40 + t * 120;
        const alpha = (1 - t) * 0.9;

        const flash = ctx.createRadialGradient(x, y, 0, x, y, radius);

        flash.addColorStop(0, `rgba(255,255,255,${alpha})`);
        flash.addColorStop(0.2, `rgba(220,235,255,${alpha * 0.7})`);
        flash.addColorStop(0.6, `rgba(160,180,255,${alpha * 0.25})`);
        flash.addColorStop(1, 'rgba(120,140,255,0)');

        ctx.fillStyle = flash;

        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();

      /* ─────────────────────────────
        ACT 2: EXPANSION (smooth cloud)
      ───────────────────────────── */
      } else if (sn.phase === 'expand') {
        sn.expandAge += 0.016;
        const t = Math.min(sn.expandAge / 4.5, 1);

        if (t >= 1) {
          sn.phase = 'fade';
          continue;
        }

        const ease = 1 - Math.pow(1 - t, 2.2);
        const r = maxR * ease;

        const pi = Math.min(
          Math.floor(t * (SN_PHASES.length - 1)),
          SN_PHASES.length - 2
        );

        const pf = t * (SN_PHASES.length - 1) - pi;

        const c0 = SN_PHASES[pi];
        const c1 = SN_PHASES[pi + 1];

        const cr = Math.round(lerp(c0.r, c1.r, pf));
        const cg = Math.round(lerp(c0.g, c1.g, pf));
        const cb = Math.round(lerp(c0.b, c1.b, pf));

        const alpha = 1 - t * 0.35;

        /* MAIN BODY — CLEAN RADIAL GRADIENT ONLY */
        const cloud = ctx.createRadialGradient(x, y, 0, x, y, r);

        cloud.addColorStop(0, `rgba(${cr},${cg},${cb},${alpha * 0.25})`);
        cloud.addColorStop(0.4, `rgba(${cr},${cg},${cb},${alpha * 0.12})`);
        cloud.addColorStop(0.8, `rgba(${cr},${cg},${cb},${alpha * 0.04})`);
        cloud.addColorStop(1, 'rgba(0,0,0,0)');

        ctx.fillStyle = cloud;

        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();

        /* CORE (soft, no edge) */
        const coreR = r * 0.18;

        const core = ctx.createRadialGradient(x, y, 0, x, y, coreR);

        core.addColorStop(0, 'rgba(255,255,255,0.9)');
        core.addColorStop(1, 'rgba(255,255,255,0)');

        ctx.fillStyle = core;

        ctx.beginPath();
        ctx.arc(x, y, coreR, 0, Math.PI * 2);
        ctx.fill();

      /* ─────────────────────────────
        ACT 3: FADE (slow dissipation)
      ───────────────────────────── */
      } else if (sn.phase === 'fade') {
        sn.fadeAge += 0.016;
        const t = Math.min(sn.fadeAge / 4.0, 1);

        if (t >= 1) {
          sn.alive = false;
          continue;
        }

        const ease = 1 - Math.pow(t, 2.0);
        const r = maxR * ease;

        const alpha = (1 - t) * 0.5;

        const remnant = ctx.createRadialGradient(x, y, 0, x, y, r);

        remnant.addColorStop(0, `rgba(120,150,255,${alpha})`);
        remnant.addColorStop(0.5, `rgba(80,110,200,${alpha * 0.3})`);
        remnant.addColorStop(1, 'rgba(0,0,0,0)');

        ctx.fillStyle = remnant;

        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    ctx.restore();
  }

/* ─────────────────────────────
   Helper: organic blob instead of circle
───────────────────────────── */
function drawBlob(ctx, x, y, radius, points, seed) {
  ctx.beginPath();

  for (let i = 0; i <= points; i++) {
    const a = (i / points) * Math.PI * 2;

    const n =
      Math.sin(a * 3 + seed) * 0.4 +
      Math.cos(a * 5 - seed * 0.7) * 0.3;

    const r = radius * (0.65 + n * 0.35);

    const px = x + Math.cos(a) * r;
    const py = y + Math.sin(a) * r;

    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }

  ctx.closePath();
  ctx.fill();
}

  /* =========================================================================
     RESIZE & INIT
     ========================================================================= */

  function resize() {
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width  = W;
    canvas.height = H;

    nebulae.length = 0;
    for (let i = 0; i < 5; i++) nebulae.push(createNebula(true));
    for (let i = 0; i < 6; i++) nebulae.push(createNebula(false));

    const s = clamp((W * H) / (1440 * 800), 0.3, 2.0);
    buildDustLayer(dustFar,  { rMin:0.28, rMax:0.75, aMin:0.040, aMax:0.095, spd:0.014, color:[215,210,255] }, Math.round(200 * s));
    buildDustLayer(dustMid,  { rMin:0.55, rMax:1.30, aMin:0.048, aMax:0.130, spd:0.028, color:[200,200,255] }, Math.round(100 * s));
    buildDustLayer(dustNear, { rMin:0.90, rMax:1.90, aMin:0.055, aMax:0.150, spd:0.052, color:[185,185,255] }, Math.round( 45 * s));
  }

  /* =========================================================================
     ANIMATION LOOP
     ========================================================================= */

  function render() {
    /* IMPORTANT: use clearRect not fillRect — the canvas must stay transparent
       so the WebGL starfield (stars.js) shows through behind it.            */
    ctx.clearRect(0, 0, W, H);
    ctx.globalCompositeOperation = 'source-over'; /* reset for dust draw */

    drawNebulae();
    drawDust();
    drawSupernovae();
    drawNovas();
  }

  function frame(ts) {
    if (!running) return;
    const dt = Math.min((ts - (lastTs || ts)) / 1000, 0.05);
    elapsed += dt;
    lastTs   = ts;

    updateCamera(dt);
    updateNebulae();
    updateDustLayer(dustFar);
    updateDustLayer(dustMid);
    updateDustLayer(dustNear);
    render();

    rafId = requestAnimationFrame(frame);
  }

  function start() {
    if (running) return;
    if (REDUCED) { resize(); render(); return; }
    running = true;
    rafId   = requestAnimationFrame(frame);
  }

  function stop() {
    running = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
  }

  /* =========================================================================
     SUPERNOVA SCHEDULER
     Checks every 2.5 s. Spawn probability increases over time so events
     feel natural after a lull, then resets to 0 after a spawn.
     ========================================================================= */
  let snTimer = 0;

  setInterval(() => {
    if (!running || document.hidden) return;
    snTimer++;
    const chance = 0.30 + Math.min(snTimer * 0.04, 0.45);
    if (Math.random() < chance && supernovae.length < 3) {
      const maxR = Math.min(W, H) * 0.32;
      const vx   = W * VOID.xFrac, vy = H * VOID.yFrac;
      let x, y, t = 0;
      do {
        x = rand(maxR, W - maxR);
        y = rand(maxR * 0.5, H - maxR * 0.5);
      } while (Math.hypot(x - vx, y - vy) < 340 && ++t < 28);

      supernovae.push({
        x, y, maxR,
        alive:     true,
        phase:     'flash',
        flashAge:  0,
        expandAge: 0,
        fadeAge:   0,
        seed:      Math.random() * 1000,
        wisps: Array.from({ length: 24 }, () => ({
          angle:  Math.random() * Math.PI * 2,
          offset: Math.random() * Math.PI * 2,
          scale:  0.7  + Math.random() * 0.6,
          width:  0.10 + Math.random() * 0.18,
        })),
      });

      snTimer = 0;
    }
  }, 2500);

  /* =========================================================================
     EVENTS
     ========================================================================= */

  window.addEventListener('mousemove', e => {
    mouse.x = e.clientX; mouse.y = e.clientY; mouse.active = true;
  }, { passive: true });

  window.addEventListener('mouseleave', () => { mouse.active = false; }, { passive: true });

  window.addEventListener('scroll', () => { scrollY = window.scrollY; }, { passive: true });

  /* Click → nova burst */
  window.addEventListener('click', e => {
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2;
      const spd   = rand(1.2, 3.5);
      novas.push({
        x: e.clientX, y: e.clientY,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd,
        life:   1,
        radius: rand(1.2, 2.8),
        color:  NOVA_COLORS[Math.floor(Math.random() * NOVA_COLORS.length)],
      });
    }
  }, { passive: true });

  let rTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(rTimer); rTimer = setTimeout(resize, 150);
  }, { passive: true });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stop(); else start();
  });

  /* ── Boot ──────────────────────────────────────────────────────────────── */
  resize();
  start();

})();

