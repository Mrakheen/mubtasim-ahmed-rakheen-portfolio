/* =========================================================================
   main.js — site bootstrap
   Preloader, navigation, scroll-reveal, ambient effects, carousel.
   No dependencies. Respects prefers-reduced-motion throughout.
   ========================================================================= */
(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const $ = (sel, ctx) => (ctx || document).querySelector(sel);
  const $$ = (sel, ctx) => Array.from((ctx || document).querySelectorAll(sel));

  /* ---------------------------------------------------------------------
     Preloader
     ─ Does NOT wait for window.load (that blocks on every CDN resource:
       Google Fonts, Font Awesome, Three.js, etc. — any slow CDN stalls it).
     ─ Instead: hides once the DOM is ready + a short minimum show-time so
       the animation has time to render at least one full cycle.
     ─ Hard cap of 1 200 ms from navigation start so it NEVER gets stuck.
     ─ Guard flag ensures hide() is idempotent (safe if called twice).
     ------------------------------------------------------------------ */
  function initPreloader() {
    const preloader = $('#preloader');
    if (!preloader) return;

    // performance.now() = ms elapsed since the navigation started,
    // so it accurately reflects how long the preloader has been visible.
    const navStart  = performance.now();
    const MIN_MS    = prefersReducedMotion ? 0 : 480;  // minimum visible time
    const MAX_MS    = 1200;                             // hard cap — never stuck

    let hidden = false;

    function hide() {
      if (hidden) return;
      hidden = true;

      const elapsed = performance.now() - navStart;
      const wait    = Math.max(0, MIN_MS - elapsed);

      setTimeout(() => {
        preloader.classList.add('is-hidden');
        // Remove from DOM after CSS transition finishes (0.6 s in style.css)
        setTimeout(() => {
          try { preloader.remove(); } catch (_) {}
        }, 660);
      }, wait);
    }

    // Hard cap — fires at most MAX_MS after navigation start
    const remaining = Math.max(0, MAX_MS - (performance.now() - navStart));
    setTimeout(hide, remaining);

    // Also listen for DOMContentLoaded in case it fires before the cap
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', hide, { once: true });
    } else {
      // DOM is already ready (script ran after parse) — hide now (respecting MIN_MS)
      hide();
    }
  }

  /* ---------------------------------------------------------------------
     Header: scrolled state + mobile menu + scrollspy
     ------------------------------------------------------------------ */
  function initHeader() {
    const header = $('#siteHeader');
    const toggle = $('#navToggle');
    const links  = $$('#navLinks a');
    if (!header) return;

    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        header.classList.toggle('is-scrolled', window.scrollY > 24);
        ticking = false;
      });
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    if (toggle) {
      toggle.addEventListener('click', () => {
        const isOpen = header.classList.toggle('nav-open');
        toggle.setAttribute('aria-expanded', String(isOpen));
      });
    }

    links.forEach((link) => {
      link.addEventListener('click', () => {
        header.classList.remove('nav-open');
        if (toggle) toggle.setAttribute('aria-expanded', 'false');
      });
    });

    // Scrollspy via IntersectionObserver
    const sections = $$('main section[id]');
    if (sections.length && 'IntersectionObserver' in window) {
      const byId = (id) => links.find((a) => a.getAttribute('href') === `#${id}`);
      const spy  = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            const link = byId(entry.target.id);
            if (!link) return;
            if (entry.isIntersecting) {
              links.forEach((a) => a.classList.remove('active'));
              link.classList.add('active');
            }
          });
        },
        { rootMargin: '-40% 0px -55% 0px', threshold: 0 }
      );
      sections.forEach((s) => spy.observe(s));
    }
  }

  /* ---------------------------------------------------------------------
     Scroll-reveal
     ------------------------------------------------------------------ */
  function initReveal() {
    const items = $$('.reveal');
    if (!items.length) return;

    if (prefersReducedMotion || !('IntersectionObserver' in window)) {
      items.forEach((el) => el.classList.add('is-visible'));
      return;
    }

    items.forEach((el, i) => el.style.setProperty('--i', i % 8));

    const io = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.13, rootMargin: '0px 0px -36px 0px' }
    );
    items.forEach((el) => io.observe(el));
  }

  /* ---------------------------------------------------------------------
     Scroll-up button
     ------------------------------------------------------------------ */
  function initScrollUp() {
    const btn = $('#scrollUp');
    if (!btn) return;
    let ticking = false;
    window.addEventListener(
      'scroll',
      () => {
        if (ticking) return;
        ticking = true;
        requestAnimationFrame(() => {
          btn.classList.toggle('show', window.scrollY > 360);
          ticking = false;
        });
      },
      { passive: true }
    );
  }

  /* ---------------------------------------------------------------------
     Writing carousel — autoplay, dots, arrows, swipe, pause on hover.
     ------------------------------------------------------------------ */
  function initCarousel() {
    const root = $('#writingCarousel');
    if (!root) return;

    const slides    = $$('[data-slide]', root);
    const dotsHost  = $('#carouselDots');
    const progressBar = $('#carouselProgressBar');
    const arrows    = $$('.carousel-arrow', root);
    if (!slides.length) return;

    let index      = Math.max(0, slides.findIndex((s) => s.classList.contains('is-active')));
    let autoplayId = null;
    const AUTOPLAY_MS = 8000;

    slides.forEach((_, i) => {
      const dot  = document.createElement('button');
      dot.type   = 'button';
      dot.setAttribute('aria-label', `Go to article ${i + 1}`);
      dot.addEventListener('click', () => goTo(i, true));
      dotsHost.appendChild(dot);
    });
    const dots = $$('button', dotsHost);

    function render() {
      slides.forEach((s, i) => s.classList.toggle('is-active', i === index));
      dots.forEach((d, i)   => d.classList.toggle('is-active', i === index));
    }

    function restartProgress() {
      if (!progressBar) return;
      progressBar.classList.remove('is-animating');
      progressBar.offsetWidth; // force reflow
      if (!prefersReducedMotion) progressBar.classList.add('is-animating');
    }

    function goTo(i, userInitiated) {
      index = (i + slides.length) % slides.length;
      render();
      restartProgress();
      if (userInitiated) restartAutoplay();
    }

    const next = () => goTo(index + 1);

    function startAutoplay()   { if (prefersReducedMotion) return; stopAutoplay(); autoplayId = setInterval(next, AUTOPLAY_MS); }
    function stopAutoplay()    { if (autoplayId) clearInterval(autoplayId); autoplayId = null; }
    function restartAutoplay() { stopAutoplay(); startAutoplay(); }

    arrows.forEach((btn) => {
      btn.addEventListener('click', () => goTo(index + Number(btn.dataset.dir), true));
    });

    root.addEventListener('mouseenter', stopAutoplay);
    root.addEventListener('mouseleave', startAutoplay);
    root.addEventListener('focusin',    stopAutoplay);
    root.addEventListener('focusout',   startAutoplay);

    // Touch swipe
    let touchX = null;
    root.addEventListener('touchstart', (e) => { touchX = e.touches[0].clientX; },        { passive: true });
    root.addEventListener('touchend',   (e) => {
      if (touchX === null) return;
      const dx = e.changedTouches[0].clientX - touchX;
      if (Math.abs(dx) > 40) goTo(index + (dx < 0 ? 1 : -1), true);
      touchX = null;
    }, { passive: true });

    render();
    restartProgress();
    startAutoplay();
  }

  /* ---------------------------------------------------------------------
     Misc
     ------------------------------------------------------------------ */
  function initMisc() {
    const year = $('#year');
    if (year) year.textContent = String(new Date().getFullYear());
  }

  /* ---------------------------------------------------------------------
     Bootstrap
     ------------------------------------------------------------------ */
  function start() {
    initPreloader();
    initHeader();
    initReveal();
    initScrollUp();
    initCarousel();
    initMisc();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();