/* ==========================================================================
   cursor.js — Interstellar Cursor (FIXED VERSION)
   Space targeting reticle · comet trail · click ripple
   ========================================================================== */

(() => {
  'use strict';

  /* ── Skip touch / no-hover devices ────────────────────────────────────── */
  if (window.matchMedia('(hover:none) and (pointer:coarse)').matches) return;

  const REDUCED = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ── Config ───────────────────────────────────────────────────────────── */
  const CFG = {
    trailMax: 16,
    followSpeed: 0.34,
    hoverSpeed: 0.42,
    hoverScale: 1.18,
    rotSpeed: 0.65,
  };

  /* ── Canvas ───────────────────────────────────────────────────────────── */
  const canvas = document.createElement('canvas');
  canvas.id = 'cursor-trail';
  document.body.appendChild(canvas);

  const ctx = canvas.getContext('2d');
  let W = 0, H = 0;

  function resizeCanvas() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  resizeCanvas();
  window.addEventListener('resize', resizeCanvas, { passive: true });

  /* ── Cursor elements ──────────────────────────────────────────────────── */
  const outer = document.createElement('div');
  outer.id = 'cursor-outer';
  outer.innerHTML = `
    <svg viewBox="0 0 44 44" fill="none">
      <circle cx="22" cy="22" r="18.5" stroke="currentColor" stroke-width="1.1"/>
      <line x1="22" y1="2"  x2="22" y2="11" stroke="currentColor" stroke-width="1.5"/>
      <line x1="22" y1="33" x2="22" y2="42" stroke="currentColor" stroke-width="1.5"/>
      <line x1="2"  y1="22" x2="11" y2="22" stroke="currentColor" stroke-width="1.5"/>
      <line x1="33" y1="22" x2="42" y2="22" stroke="currentColor" stroke-width="1.5"/>
      <circle cx="22" cy="22" r="2.2" stroke="currentColor" stroke-width="1"/>
    </svg>
  `;
  document.body.appendChild(outer);

  const core = document.createElement('div');
  core.id = 'cursor-core';
  document.body.appendChild(core);

  /* ── State ────────────────────────────────────────────────────────────── */
  let mouseX = -500, mouseY = -500;
  let ringX = -500, ringY = -500;
  let visible = false;
  let hovering = false;
  let scale = 1;
  let rotation = 0;

  const trail = [];
  const ripples = [];

  const INTERACTIVE =
    'a,button,[role=button],input,textarea,select,' +
    '.btn,.project-card,.stack-chip,.feature-card,' +
    '.carousel-arrow,.profile-frame,.nav-links a';

  const lerp = (a, b, t) => a + (b - a) * t;

  /* ── Mouse events ─────────────────────────────────────────────────────── */
  document.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
    visible = true;

    const isHover = !!e.target.closest(INTERACTIVE);
    if (isHover !== hovering) {
      hovering = isHover;
      document.body.classList.toggle('cursor-hover', hovering);
    }

    if (!REDUCED) {
      trail.push({ x: mouseX, y: mouseY });
      if (trail.length > CFG.trailMax) trail.shift();
    }
  }, { passive: true });

  document.addEventListener('mouseleave', () => {
    visible = false;
    document.body.classList.remove('cursor-hover');
  });

  document.addEventListener('mousedown', () => {
    document.body.classList.add('cursor-click');
    if (!REDUCED) {
      ripples.push({ x: mouseX, y: mouseY, r: 0, a: 0.8 });
    }
    setTimeout(() => document.body.classList.remove('cursor-click'), 150);
  });

  /* ── Draw trail ───────────────────────────────────────────────────────── */
  function drawTrail() {
    if (trail.length < 2) return;

    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    for (let i = 1; i < trail.length; i++) {
      const p0 = trail[i - 1];
      const p1 = trail[i];
      const t = i / trail.length;

      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y);
      ctx.lineTo(p1.x, p1.y);

      ctx.strokeStyle = `rgba(255,255,255,${t * 0.5})`;
      ctx.lineWidth = 0.5 + t * 2.5;
      ctx.stroke();
    }

    const head = trail[trail.length - 1];
    if (!head) return;

    const glow = ctx.createRadialGradient(head.x, head.y, 0, head.x, head.y, 24);
    glow.addColorStop(0, "rgba(255,255,255,1)");
    glow.addColorStop(0.3, "rgba(255,255,255,0.6)");
    glow.addColorStop(1, "rgba(255,255,255,0)");

    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(head.x, head.y, 24, 0, Math.PI * 2);
    ctx.fill();
  }

  /* ── Draw ripples ─────────────────────────────────────────────────────── */
  function drawRipples() {
    for (let i = ripples.length - 1; i >= 0; i--) {
      const rp = ripples[i];
      rp.r += 3;
      rp.a *= 0.88;

      if (rp.a < 0.01) {
        ripples.splice(i, 1);
        continue;
      }

      ctx.beginPath();
      ctx.arc(rp.x, rp.y, rp.r, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(42,241,214,${rp.a})`;
      ctx.lineWidth = 1.2;
      ctx.stroke();
    }
  }

  /* ── Animation loop ───────────────────────────────────────────────────── */
  function animate() {
    requestAnimationFrame(animate);
    ctx.clearRect(0, 0, W, H);

    if (!visible) {
      outer.style.opacity = '0';
      core.style.opacity = '0';
      return;
    }

    const spd = hovering ? CFG.hoverSpeed : CFG.followSpeed;

    ringX = lerp(ringX, mouseX, spd);
    ringY = lerp(ringY, mouseY, spd);

    scale = lerp(scale, hovering ? CFG.hoverScale : 1, 0.15);
    rotation += REDUCED ? 0 : CFG.rotSpeed;

    outer.style.transform =
      `translate3d(${ringX - 22}px,${ringY - 22}px,0)
       rotate(${rotation}deg)
       scale(${scale})`;

    core.style.transform =
      `translate3d(${mouseX - 3}px,${mouseY - 3}px,0)`;

    outer.style.opacity = '1';
    core.style.opacity = '1';

    if (!REDUCED) {
      drawTrail();
      drawRipples();
    }
  }

  animate();
})();