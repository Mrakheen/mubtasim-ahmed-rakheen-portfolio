/* =========================================================================
   stars.js — Deep background WebGL starfield
   Six point-cloud layers, dual-frequency organic twinkle shader,
   soft gaussian bloom per star, subtle camera drift (floating-in-space feel).
   ========================================================================= */
import * as THREE from 'three';

(function () {
  const container = document.getElementById('stars-js');
  if (!container) return;
  if (!window.WebGLRenderingContext) return;

  const reduced = window.matchMedia('(prefers-reduced-motion:reduce)').matches;

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({
      alpha: true, antialias: true, powerPreference: 'low-power'
    });
  } catch (e) { return; }

  renderer.setPixelRatio(Math.min(window.devicePixelRatio, reduced ? 1 : 2));
  renderer.setClearColor(0x000000, 0);
  renderer.setSize(window.innerWidth, window.innerHeight);
  container.appendChild(renderer.domElement);

  const scene  = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(
    55, window.innerWidth / window.innerHeight, 0.01, 500
  );
  camera.position.set(0, 0, 6);
  camera.lookAt(0, 0, 0);

  /* ── Shaders ─────────────────────────────────────────────────────── */
  const VERT = `
    attribute float aSize;
    attribute float aPhase;
    attribute float aFreq;     /* each star has its own twinkle frequency */
    attribute vec3  aColor;
    varying   vec3  vColor;
    uniform   float uTime;

    void main() {
      vColor = aColor;

      vec4  mvPos = modelViewMatrix * vec4(position, 1.0);
      float dist  = length(mvPos.xyz);

      /* Dual-frequency twinkle — two overlapping sine waves per star    */
      /* Golden-ratio multiplier on freq2 ensures no periodic sync       */
      float t1 = sin(uTime * aFreq          + aPhase);
      float t2 = sin(uTime * aFreq * 2.618  + aPhase * 1.414);
      float tw = 0.70 + 0.18 * t1 + 0.12 * t2;

      gl_PointSize = (aSize / dist) * tw * 270.0;
      gl_Position  = projectionMatrix * mvPos;
    }
  `;

  const FRAG = `
    varying vec3 vColor;

    void main() {
      vec2  uv = gl_PointCoord - 0.5;
      float d  = length(uv);
      if (d > 0.5) discard;

      /* Tight gaussian core + wide soft bloom — gives each star a halo */
      float core  = exp(-d * d * 10.0);
      float bloom = exp(-d * d * 2.6) * 0.38;

      gl_FragColor = vec4(vColor, core + bloom);
    }
  `;

  function makeShaderMat (uTime) {
    return new THREE.ShaderMaterial({
      uniforms:       { uTime },
      vertexShader:   VERT,
      fragmentShader: FRAG,
      transparent:    true,
      depthWrite:     false,
      blending:       THREE.AdditiveBlending,
    });
  }

  /* ── Geometry helpers ────────────────────────────────────────────── */
  function spherePoint (r) {
    const theta = Math.random() * Math.PI * 2;
    const phi   = Math.acos(2 * Math.random() - 1);
    return [
      r * Math.sin(phi) * Math.cos(theta),
      r * Math.sin(phi) * Math.sin(theta),
      r * Math.cos(phi),
    ];
  }

  function volumePoint (spread) {
    // cluster bias: mixes dense core + sparse outer shell
    const bias = Math.random();

    const r = spread * (
      bias < 0.65
        ? Math.pow(Math.random(), 0.65)   // denser clusters
        : Math.cbrt(Math.random()) * 1.2   // outer scatter
    );

    const theta = Math.random() * Math.PI * 2;
    const phi   = Math.acos(2 * Math.random() - 1);

      return [
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.sin(phi) * Math.sin(theta),
        r * Math.cos(phi),
      ];
  }

  /* ── Layer builder ───────────────────────────────────────────────── */
  function makeLayer ({ count, sizeMean, sizeVar, colorFn, freqMin, freqMax, spread, rotSpeed }) {
    const pos    = new Float32Array(count * 3);
    const cols   = new Float32Array(count * 3);
    const sizes  = new Float32Array(count);
    const phases = new Float32Array(count);
    const freqs  = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      const p = volumePoint(spread);
      pos[i * 3]     = p[0];
      pos[i * 3 + 1] = p[1];
      pos[i * 3 + 2] = p[2];

      const c = colorFn();
      cols[i * 3]     = c[0];
      cols[i * 3 + 1] = c[1];
      cols[i * 3 + 2] = c[2];

      sizes[i]  = sizeMean + (Math.random() - 0.5) * sizeVar;
      phases[i] = Math.random() * Math.PI * 2;
      freqs[i]  = freqMin + Math.random() * (freqMax - freqMin);
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos,    3));
    geo.setAttribute('aColor',   new THREE.BufferAttribute(cols,   3));
    geo.setAttribute('aSize',    new THREE.BufferAttribute(sizes,  1));
    geo.setAttribute('aPhase',   new THREE.BufferAttribute(phases, 1));
    geo.setAttribute('aFreq',    new THREE.BufferAttribute(freqs,  1));

    const uTime = { value: 0 };
    return { mesh: new THREE.Points(geo, makeShaderMat(uTime)), uTime, rotSpeed };
  }

  /* ── Colour functions ────────────────────────────────────────────── */
  const WHITE  = () => [0.92 + Math.random() * 0.08, 0.92 + Math.random() * 0.08, 1.00];
  const VIOLET = () => [0.65 + Math.random() * 0.22, 0.26 + Math.random() * 0.16, 1.00];
  const AURORA = () => [0.18 + Math.random() * 0.16, 0.88 + Math.random() * 0.12, 0.78 + Math.random() * 0.20];
  const WARM   = () => [1.00, 0.80 + Math.random() * 0.20, 0.50 + Math.random() * 0.28];
  const ROSE   = () => [1.00, 0.32 + Math.random() * 0.22, 0.62 + Math.random() * 0.22];
  const COLD   = () => [0.60 + Math.random() * 0.20, 0.80 + Math.random() * 0.15, 1.00];

  const compact = Math.min(window.innerWidth, window.innerHeight) < 700;
  const ds      = compact ? 0.50 : 1.0;

  /* Six layers — variety gives depth and richness */
  const layerDefs = [
    /* 1. Distant sparse field (reduced) */
    { count: Math.round(380 * ds), sizeMean: 0.0045, sizeVar: 0.003, colorFn: WHITE,
      freqMin: 0.4, freqMax: 2.2, spread: 8.5, rotSpeed: 0.0000025 },

    /* 2. Mid field (reduced + slightly denser clustering) */
    { count: Math.round(220 * ds), sizeMean: 0.0090, sizeVar: 0.006, colorFn: WHITE,
      freqMin: 0.5, freqMax: 2.0, spread: 5.0, rotSpeed: 0.000008 },

    /* 3. Cold stars */
    { count: Math.round(90 * ds), sizeMean: 0.0075, sizeVar: 0.004, colorFn: COLD,
      freqMin: 0.8, freqMax: 2.8, spread: 5.5, rotSpeed: 0.000006 },

    /* 4. Violet structure layer */
    { count: Math.round(120 * ds), sizeMean: 0.0080, sizeVar: 0.005, colorFn: VIOLET,
      freqMin: 0.6, freqMax: 2.5, spread: 6.5, rotSpeed: 0.0000055 },

    /* 5. Warm foreground (slightly stronger but fewer) */
    { count: Math.round(55 * ds), sizeMean: 0.0220, sizeVar: 0.010, colorFn: WARM,
      freqMin: 0.3, freqMax: 1.4, spread: 3.5, rotSpeed: 0.000014 },

    /* 6. Accent aurora */
    { count: Math.round(65 * ds), sizeMean: 0.0130, sizeVar: 0.007, colorFn: AURORA,
      freqMin: 0.7, freqMax: 2.4, spread: 4.0, rotSpeed: 0.000009 },

    { count: Math.round(30 * ds), sizeMean: 0.0170, sizeVar: 0.007, colorFn: ROSE,
      freqMin: 0.9, freqMax: 2.8, spread: 4.5, rotSpeed: 0.000011 },
  ];

  const layers = layerDefs.map(def => {
    const layer = makeLayer(def);
    scene.add(layer.mesh);
    return layer;
  });

  /* ── Animation ───────────────────────────────────────────────────── */
  const clock = new THREE.Clock();
  let rafId = null, isRunning = false;

  function renderOnce () {
    const t = clock.getElapsedTime();
    layers.forEach(({ uTime }) => { uTime.value = t; });
    renderer.render(scene, camera);
  }

  function animate () {
    if (!isRunning) return;
    const t = clock.getElapsedTime();

    /* Subtle camera drift — like slowly floating through deep space     */
    /* Amplitude kept tiny so the starfield doesn't feel wobbly         */
    camera.position.x =
      Math.sin(t * 0.012) * 0.28 +
      Math.sin(t * 0.031) * 0.08;

    camera.position.y =
      Math.cos(t * 0.009) * 0.22 +
      Math.sin(t * 0.027) * 0.06;
    camera.lookAt(0, 0, 0);

    layers.forEach(({ mesh, uTime, rotSpeed }) => {
      mesh.rotation.y += rotSpeed;
      mesh.rotation.x  = Math.sin(t * 0.016) * 0.035;
      uTime.value = t;
    });

    renderer.render(scene, camera);
    rafId = requestAnimationFrame(animate);
  }

  function start () {
    if (isRunning || reduced) return;
    isRunning = true;
    clock.start();
    rafId = requestAnimationFrame(animate);
  }
  function stop () {
    isRunning = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
  }

  if (reduced) {
    renderOnce();
  } else {
    document.addEventListener('visibilitychange',
      () => document.hidden ? stop() : start());
    start();
  }

  /* ── Resize ──────────────────────────────────────────────────────── */
  let resizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
      if (reduced) renderOnce();
    }, 150);
  });
})();
