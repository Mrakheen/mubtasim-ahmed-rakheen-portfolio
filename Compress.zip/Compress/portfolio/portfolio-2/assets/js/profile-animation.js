/* =========================================================================
   profile-animation.js — 3-D tilt effect on the About profile photo
   Uses pointer events (works on mouse and stylus).
   Uses CSS custom property --perspective so the value can be themed in CSS.
   ========================================================================= */
(function () {
  'use strict';

  const frame = document.getElementById('profileFrame');
  if (!frame) return;

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefersReducedMotion) return;

  const MAX_ROT = 14; // degrees max rotation in any direction
  const SCALE   = 1.06;

  let rafId = null;
  let targetX = 0;
  let targetY = 0;
  let currentX = 0;
  let currentY = 0;
  let isHovering = false;
  const LERP = 0.12; // smoothing factor per frame (0 = instant, 1 = no movement)

  function lerp(a, b, t) { return a + (b - a) * t; }

  function animate() {
    currentX = lerp(currentX, targetX, LERP);
    currentY = lerp(currentY, targetY, LERP);

    frame.style.transform =
      `perspective(1000px) rotateX(${currentX.toFixed(3)}deg) rotateY(${currentY.toFixed(3)}deg) scale(${SCALE})`;

    const distMoved = Math.abs(currentX - targetX) + Math.abs(currentY - targetY);
    if (isHovering || distMoved > 0.02) {
      rafId = requestAnimationFrame(animate);
    } else {
      // Fully reset — don't keep the rAF loop running needlessly
      frame.style.transform = '';
      rafId = null;
    }
  }

  function startLoop() {
    if (!rafId) rafId = requestAnimationFrame(animate);
  }

  frame.addEventListener('pointermove', (e) => {
    const rect = frame.getBoundingClientRect();
    const cx   = rect.left + rect.width  / 2;
    const cy   = rect.top  + rect.height / 2;

    const nx = (e.clientX - cx) / (rect.width  / 2); // –1 … 1
    const ny = (e.clientY - cy) / (rect.height / 2); // –1 … 1

    targetX = -ny * MAX_ROT; // tilt up/down  (rotateX)
    targetY =  nx * MAX_ROT; // tilt left/right (rotateY)

    isHovering = true;
    startLoop();
  });

  frame.addEventListener('pointerenter', () => { isHovering = true; });

  frame.addEventListener('pointerleave', () => {
    isHovering = false;
    targetX = 0;
    targetY = 0;
    startLoop(); // let the lerp smoothly ease back to (0,0)
  });
})();
