 /* =========================================================================
   avatar.js — interactive 3D avatar dock
   Loads avatar.glb (Avaturn export) and renders it with image-based
   lighting (RoomEnvironment + PMREMGenerator) and ACES filmic tone mapping
   for a more realistic, less "flat-plastic" PBR look. Adds a small glowing
   pedestal ring and an orbiting particle aura that pulses when the avatar
   is clicked, tying the avatar into the rest of the particle/star theme.
   ========================================================================= */
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const container = document.getElementById('avatar-container');
const loadingEl = document.getElementById('avatar-loading');
const tooltipEl = container ? container.querySelector('.tooltip') : null;
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

if (container && window.WebGLRenderingContext) {
  try {
    loadModel();
  } catch (err) {
    console.error(err);
    showError();
  }
}

function showError() {
  if (loadingEl) loadingEl.classList.add('is-hidden');
  if (container) container.classList.add('has-error');
}

function loadModel() {
  const loader = new GLTFLoader();

  loader.load(
    'avatar.glb',
    (gltf) => {
      setupScene(gltf);
      if (loadingEl) loadingEl.classList.add('is-hidden');
    },
    (xhr) => {
      if (xhr.total && loadingEl) {
        const percent = Math.round((xhr.loaded / xhr.total) * 100);
        loadingEl.textContent = `Initializing avatar… ${percent}%`;
      }
    },
    (error) => {
      console.error('Avatar failed to load:', error);
      showError();
    }
  );
}

function setupScene(gltf) {
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
  } catch (e) {
    showError();
    return;
  }

  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  renderer.setSize(container.clientWidth, container.clientHeight);
  container.appendChild(renderer.domElement);

  // Camera ----------------------------------------------------------------
  const camera = new THREE.PerspectiveCamera(
    45,
    container.clientWidth / container.clientHeight,
    0.1,
    100
  );
  camera.position.set(0.2, 0.5, 1);

  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.enablePan = false;
  controls.enableZoom = false;
  controls.minDistance = 3;
  controls.minPolarAngle = 1.4;
  controls.maxPolarAngle = 1.4;
  controls.target = new THREE.Vector3(0, 0.75, 0);
    controls.autoRotate = false;
  controls.update();

  // Scene + image-based lighting -------------------------------------------
  const scene = new THREE.Scene();

  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  pmrem.dispose();

  const ambientLight = new THREE.AmbientLight(0xffffff, 1.1);
  scene.add(ambientLight);

  const spotlight = new THREE.SpotLight(0xffffff, 20, 8, 1);
  spotlight.penumbra = 0.5;
  spotlight.position.set(0, 4, 2);
  spotlight.castShadow = true;
  spotlight.shadow.mapSize.set(1024, 1024);
  spotlight.shadow.bias = -0.0015;
  scene.add(spotlight);

  const keyLight = new THREE.DirectionalLight(0xffffff, 2);
  keyLight.position.set(1, 1, 2);
  keyLight.lookAt(new THREE.Vector3());
  scene.add(keyLight);

  // subtle violet rim light for cohesion with the page's color theme
  const rimLight = new THREE.DirectionalLight(0xbf5cff, 0.8);
  rimLight.position.set(-1.4, 1, -1.2);
  scene.add(rimLight);

  // Avatar ------------------------------------------------------------------
  const avatar = gltf.scene;
  avatar.traverse((child) => {
    if (child.isMesh) {
      child.castShadow = true;
      child.receiveShadow = true;
    }
  });
  avatar.scale.set(1.05, 1.02, 1.05);
  scene.add(avatar);

  // Hologram pedestal --------------------------------------------------------
  const groundGeometry = new THREE.CylinderGeometry(0.6, 0.6, 0.1, 64);
  const groundMaterial = new THREE.MeshStandardMaterial({ color: 0x140222, metalness: 0.5, roughness: 0.4 });
  const groundMesh = new THREE.Mesh(groundGeometry, groundMaterial);
  groundMesh.receiveShadow = true;
  groundMesh.position.y -= 0.05;
  scene.add(groundMesh);

  const ringGeometry = new THREE.TorusGeometry(0.61, 0.012, 12, 80);
  const ringMaterial = new THREE.MeshStandardMaterial({
    color: 0x05000c,
    emissive: 0x6fffe9,
    emissiveIntensity: 1.6,
    roughness: 0.5,
  });
  const ring = new THREE.Mesh(ringGeometry, ringMaterial);
  ring.rotation.x = Math.PI / 2;
  ring.position.y = -0.045;
  scene.add(ring);

  // Particle aura — small glowing ring of points orbiting the pedestal,
  // ties the avatar into the same star/particle visual language as the
  // rest of the page. Pulses briefly when the avatar is clicked.
  const aura = createAura();
  scene.add(aura.points);

  // Animations ----------------------------------------------------------------
  const mixer = new THREE.AnimationMixer(avatar);
  const clips = gltf.animations;
  const standing_greetingClip = THREE.AnimationClip.findByName(clips, 'standing_greeting');
  const saluteClip = THREE.AnimationClip.findByName(clips, 'salute');
  const stumbleClip = THREE.AnimationClip.findByName(clips, 'stumble');
  const standing_greetingAction = mixer.clipAction(standing_greetingClip);
  const saluteAction = mixer.clipAction(saluteClip);
  const stumbleAction = mixer.clipAction(stumbleClip);

  function hideTooltip() {
    if (tooltipEl) tooltipEl.style.display = 'none';
  }

  function pointerPos(ev) {
    const rect = container.getBoundingClientRect();
    return {
      x: ((ev.clientX - rect.left) / rect.width) * 2 - 1,
      y: -((ev.clientY - rect.top) / rect.height) * 2 + 1,
    };
  }

  let isStumbling = false;
  const raycasterClick = new THREE.Raycaster();
  container.addEventListener('pointerdown', (ev) => {
    const coords = pointerPos(ev);
    raycasterClick.setFromCamera(coords, camera);
    const intersections = raycasterClick.intersectObject(avatar, true);

    if (intersections.length > 0) {
      hideTooltip();
      aura.pulse();
      if (isStumbling) return;

      isStumbling = true;
      stumbleAction.reset();
      stumbleAction.play();
      standing_greetingAction.crossFadeTo(stumbleAction, 0.3);

      setTimeout(() => {
        standing_greetingAction.reset();
        standing_greetingAction.play();
        stumbleAction.crossFadeTo(standing_greetingAction, 1);
        setTimeout(() => { isStumbling = false; }, 1000);
      }, 4000);
    }
  });

  let isSaluting = false;
  const raycasterHover = new THREE.Raycaster();
  container.addEventListener('pointermove', (ev) => {
    const coords = pointerPos(ev);
    raycasterHover.setFromCamera(coords, camera);
    const intersections = raycasterHover.intersectObject(avatar, true);

    if (intersections.length > 0) {
      hideTooltip();
      if (isSaluting) return;

      isSaluting = true;
      saluteAction.reset();
      saluteAction.play();
      standing_greetingAction.crossFadeTo(saluteAction, 0.3);

      setTimeout(() => {
        standing_greetingAction.reset();
        standing_greetingAction.play();
        saluteAction.crossFadeTo(standing_greetingAction, 1);
        setTimeout(() => { isSaluting = false; }, 1000);
      }, 4000);
    }
  });

  // Resize --------------------------------------------------------------------
  let resizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    }, 120);
  });

  // Render loop — paused off-screen and when the tab is hidden ----------------
  const clock = new THREE.Clock();
  let rafId = null;
  let isRunning = false;

  function frame() {
    if (!isRunning) return;
    const dt = clock.getDelta();
    mixer.update(dt);
    controls.update();
    aura.update(dt);
    renderer.render(scene, camera);
    rafId = requestAnimationFrame(frame);
  }
  function start() {
    if (isRunning) return;
    isRunning = true;
    rafId = requestAnimationFrame(frame);
  }
  function stop() {
    isRunning = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
  }

  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => (e.isIntersecting ? start() : stop())),
      { threshold: 0 }
    );
    io.observe(container);
  } else {
    start();
  }
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stop();
    else if (container.getBoundingClientRect().top < window.innerHeight) start();
  });

  standing_greetingAction.play();
}

/* ---------------------------------------------------------------------
   Orbiting particle aura around the pedestal — same twinkle-shader
   technique as the global starfield, kept local to this scene.
   ------------------------------------------------------------------ */
function createAura() {
  const COUNT = 70;
  const positions = new Float32Array(COUNT * 3);
  const colors = new Float32Array(COUNT * 3);
  const sizes = new Float32Array(COUNT);
  const phases = new Float32Array(COUNT);

  for (let i = 0; i < COUNT; i++) {
    const angle = Math.random() * Math.PI * 2;
    const radius = 0.72 + Math.random() * 0.34;
    positions[i * 3] = Math.cos(angle) * radius;
    positions[i * 3 + 1] = Math.random() * 0.5 - 0.02;
    positions[i * 3 + 2] = Math.sin(angle) * radius;

    const mixT = Math.random();
    colors[i * 3] = 0.45 + mixT * 0.35;       // r: violet -> aurora blend
    colors[i * 3 + 1] = 0.35 + mixT * 0.55;   // g
    colors[i * 3 + 2] = 0.95;                 // b

    sizes[i] = 0.012 + Math.random() * 0.014;
    phases[i] = Math.random() * Math.PI * 2;
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));
  geo.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  geo.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));

  const uniforms = { uTime: { value: 0 }, uBoost: { value: 1.0 } };

  const mat = new THREE.ShaderMaterial({
    uniforms,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: `
      attribute float aSize;
      attribute float aPhase;
      attribute vec3 aColor;
      varying vec3 vColor;
      uniform float uTime;
      uniform float uBoost;
      void main() {
        vColor = aColor;
        vec4 mvPos = modelViewMatrix * vec4(position, 1.0);
        float twinkle = 0.7 + 0.3 * sin(uTime * 2.0 + aPhase);
        gl_PointSize = aSize * twinkle * uBoost * 420.0;
        gl_Position = projectionMatrix * mvPos;
      }
    `,
    fragmentShader: `
      varying vec3 vColor;
      uniform float uBoost;
      void main() {
        vec2 uv = gl_PointCoord - 0.5;
        float d = length(uv);
        if (d > 0.5) discard;
        float alpha = exp(-d * d * 9.0) * min(uBoost, 1.6);
        gl_FragColor = vec4(vColor, alpha * 0.85);
      }
    `,
  });

  const points = new THREE.Points(geo, mat);
  let pulseUntil = 0;

  return {
    points,
    update(dt) {
      uniforms.uTime.value += dt;
      points.rotation.y += dt * 0.22;
      const now = performance.now();
      if (now < pulseUntil) {
        const remaining = (pulseUntil - now) / 650; // 0..1
        uniforms.uBoost.value = 1 + remaining * 0.9;
      } else if (uniforms.uBoost.value !== 1) {
        uniforms.uBoost.value = 1;
      }
    },
    pulse() {
      pulseUntil = performance.now() + 650;
    },
  };
}                               









